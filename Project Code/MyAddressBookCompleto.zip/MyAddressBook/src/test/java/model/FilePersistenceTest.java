package model;

import org.junit.jupiter.api.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the FilePersistence class.
 *
 * @author davidepernaruggiero
 */
class FilePersistenceTest {

    private static final String TEST_PATH = "test_contacts.csv";
    private FilePersistence persistence;

    @BeforeEach
    void setUp() {
        // Deletes any existing test file before each run to ensure a clean environment
        try { Files.deleteIfExists(Paths.get(TEST_PATH)); } catch (IOException ignored) {}
        persistence = new FilePersistence(TEST_PATH);
    }

    @AfterEach
    void tearDown() {
        // Removes the test file after each test to avoid leftover data
        try { Files.deleteIfExists(Paths.get(TEST_PATH)); } catch (IOException ignored) {}
    }

    private Contact createSampleContact() {
        // Helper method that returns a valid sample contact used across multiple tests
        return new Contact(
                UUID.randomUUID(),
                "Mario",
                "Rossi",
                Arrays.asList("123456"),
                Arrays.asList("mario@rossi.it"),
                "ACME",
                "note di test",
                true
        );
    }

    @Test
    void testFileIsCreated() {
        // Verifies that the persistence file is created upon initialization
        assertTrue(Files.exists(Paths.get(TEST_PATH)));
    }

    @Test
    void testAppendContact() {
        // Ensures that adding a contact writes a new record to the file
        Contact c = createSampleContact();
        assertTrue(persistence.appendContact(c));

        List<Contact> loaded = persistence.loadContacts();
        assertEquals(1, loaded.size());
        assertEquals("Mario", loaded.get(0).getFirstName());
    }

    @Test
    void testUpdateContact() {
        // Validates that updating an existing contact correctly overwrites its data in the file
        Contact c = createSampleContact();
        persistence.appendContact(c);

        c = new Contact(c.getId(), "Marco", "Rossi",
                c.getPhoneNumbers(), c.getEmails(),
                c.getCompany(), c.getNotes(), c.isFavorite());
        assertTrue(persistence.updateContact(c));

        List<Contact> updated = persistence.loadContacts();
        assertEquals("Marco", updated.get(0).getFirstName());
    }

    @Test
    void testDeleteContact() {
        // Confirms that deleting a contact removes its entry from the CSV file
        Contact c = createSampleContact();
        persistence.appendContact(c);
        assertTrue(persistence.deleteContact(c.getId()));
        assertTrue(persistence.loadContacts().isEmpty());
    }

    @Test
    void testParseList() {
        // Checks that parseList correctly handles null, empty, and valid input strings
        assertTrue(persistence.parseList(null).isEmpty());
        assertTrue(persistence.parseList("").isEmpty());
        assertEquals(Arrays.asList("a", "b"), persistence.parseList("a;b"));
    }

    @Test
    void testFileExists() {
        // Ensures fileExists() correctly reports the file’s presence or absence
        assertTrue(persistence.fileExists());
        try { Files.deleteIfExists(Paths.get(TEST_PATH)); } catch (IOException ignored) {}
        assertFalse(persistence.fileExists());
    }

    @Test
    void testLoadContacts() throws IOException {
        // Verifies that malformed data in the file does not crash the load process
        Files.write(Paths.get(TEST_PATH), Arrays.asList("bad;data;not;parsable"));
        assertDoesNotThrow(() -> persistence.loadContacts());
    }
}