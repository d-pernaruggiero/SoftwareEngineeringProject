/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import javafx.collections.ObservableList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.UUID;
import java.util.Arrays;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the AddressBook class
 * 
 * @author davidepernaruggiero
 */
class AddressBookTest {

    private AddressBook addressBook;
    private Contact mario;
    private Contact luigi;
    private Contact anna;

    @BeforeEach
    void setUp() {
        addressBook = new AddressBook();

        mario = new Contact(UUID.randomUUID(), "Mario", "Rossi",
                Arrays.asList("+39081234567"), Arrays.asList("mario@example.com"),
                "ACME", "", false);

        luigi = new Contact(UUID.randomUUID(), "Luigi", "Verdi",
                Arrays.asList("+39333111222"), Arrays.asList("luigi@example.com"),
                "ACME", "", true);

        anna = new Contact(UUID.randomUUID(), "Anna", "Bianchi",
                Arrays.asList("+39023456789"), Arrays.asList("anna@example.com"),
                "ACME", "", false);
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    void testAddContact() {
        // Verifies that a new contact can be added successfully
        assertTrue(addressBook.addContact(mario));
        assertTrue(addressBook.contains(mario));
    }
    
    @Test
    void testErrataAddContact() {
        // Ensures that a contact with the same ID cannot be added twice
        assertTrue(addressBook.addContact(mario));
        assertFalse(addressBook.addContact(mario));
    }
    
    @Test
    void testIndexOfAndGetContact() {
        // Tests correct retrieval of a contact by its unique UUID
        addressBook.addContact(mario);
        int idx = addressBook.indexOf(mario.getId());
        assertEquals(0, idx);
        assertEquals(mario, addressBook.getContact(mario.getId()));
        assertNull(addressBook.getContact(UUID.randomUUID()));
    }

    @Test
    void testUpdateExistingContact() {
        // Validates that an existing contact can be updated and saved correctly
        addressBook.addContact(mario);
        Contact updated = new Contact(mario.getId(), "Mario", "Rossi",
                Arrays.asList("+39999999999"), Arrays.asList("newmail@example.com"),
                "ACME", "note", false);
        assertTrue(addressBook.saveContact(updated));
        assertEquals("newmail@example.com", addressBook.getContact(mario.getId()).getEmails().get(0));
    }

    @Test
    void testSaveContactNotFound() {
        // Ensures that saving a non-existing contact returns false
        assertFalse(addressBook.saveContact(mario));
    }

    @Test
    void testRemoveContact() {
        // Verifies that an existing contact can be successfully removed
        addressBook.addContact(luigi);
        assertTrue(addressBook.removeContact(luigi));
        assertFalse(addressBook.contains(luigi));
    }

    @Test
    void testSearch() {
        // Checks that searching by a substring returns matching contacts only
        addressBook.addContact(mario);
        addressBook.addContact(luigi);
        ObservableList<Contact> result = addressBook.search("ros");
        assertEquals(1, result.size());
        assertEquals(mario, result.get(0));
    }

    @Test
    void testSearchIfEmpty() {
        // Confirms that an empty query returns all contacts
        addressBook.addContact(mario);
        addressBook.addContact(luigi);
        assertEquals(2, addressBook.search("").size());
    }

    @Test
    void testFilterFavorites() {
        // Checks that filtering by "favorite" returns only contacts marked as favorites
        addressBook.addContact(mario);
        addressBook.addContact(luigi);
        ObservableList<Contact> favs = addressBook.filterFavorites();
        assertEquals(1, favs.size());
        assertTrue(favs.get(0).isFavorite());
    }

    @Test
    void testSortByFirstNameAscending() {
        // Ensures correct ascending sorting by first name
        addressBook.addContact(luigi);
        addressBook.addContact(anna);
        addressBook.sortByFirstNameAscending();
        assertEquals("Anna", addressBook.getObservableContacts().get(0).getFirstName());
    }

    @Test
    void testSortByLastNameAscending() {
        // Ensures correct ascending sorting by last name
        addressBook.addContact(luigi);
        addressBook.addContact(anna);
        addressBook.sortByLastNameAscending();
        assertEquals("Bianchi", addressBook.getObservableContacts().get(0).getLastName());
    }

    @Test
    void testSortByFirstNameDescending() {
        // Ensures correct descending sorting by first name
        addressBook.addContact(luigi);
        addressBook.addContact(anna);
        addressBook.sortByFirstNameDescending();
        assertEquals("Luigi", addressBook.getObservableContacts().get(0).getFirstName());
    }

    @Test
    void testSortByLastNameDescending() {
        // Ensures correct descending sorting by last name
        addressBook.addContact(luigi);
        addressBook.addContact(anna);
        addressBook.sortByLastNameDescending();
        assertEquals("Verdi", addressBook.getObservableContacts().get(0).getLastName());
    }

    @Test
    void testGetObservableContactsLive() {
        // Verifies that the observable list is live and reflects changes in real-time
        addressBook.addContact(mario);
        ObservableList<Contact> list = addressBook.getObservableContacts();
        assertEquals(1, list.size());
        list.add(luigi);
        assertEquals(2, addressBook.getObservableContacts().size());
    }

    @Test
    void testModificationConsistency() throws InterruptedException {
        // Tests that concurrent modifications from two threads do not cause inconsistencies
        Contact c1 = new Contact(UUID.randomUUID(), "Luca", "Verdi", null, null, "", "", false);
        Contact c2 = new Contact(UUID.randomUUID(), "Paolo", "Bianchi", null, null, "", "", false);

        Thread t1 = new Thread(() -> addressBook.addContact(c1));
        Thread t2 = new Thread(() -> addressBook.addContact(c2));

        t1.start();
        t2.start();
        t1.join();
        t2.join();

        assertTrue(addressBook.getObservableContacts().containsAll(Arrays.asList(c1, c2)));
        assertEquals(2, addressBook.getObservableContacts().size());
    }
}