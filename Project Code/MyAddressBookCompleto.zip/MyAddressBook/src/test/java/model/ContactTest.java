/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.*;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Contact class.
 *
 * @author davidepernaruggiero
 */


class ContactTest {

    private Contact contact;

    @BeforeEach
    void setUp() {
        // Initializes a sample contact before each test
        contact = new Contact(null, "Mario", "Rossi",
                Arrays.asList("+39081234567"), Arrays.asList("mario.rossi@example.com"),
                "ACME", "Note di prova", true);
    }
    
    @AfterEach
    public void tearDown() {
    }
    
    @Test
    void testDefaultConstructor() {
        // Ensures that the default constructor throws an exception for invalid initialization
        assertThrows(IllegalArgumentException.class, Contact::new);
    }

    @Test
    void testFullConstructor() {
        // Verifies that all fields are correctly assigned by the full constructor
        assertEquals("Mario", contact.getFirstName());
        assertEquals("Rossi", contact.getLastName());
        assertEquals(1, contact.getPhoneNumbers().size());
        assertEquals(1, contact.getEmails().size());
        assertEquals("ACME", contact.getCompany());
        assertTrue(contact.isFavorite());
    }

    @Test
    void testSetFullName() {
        // Checks that setting an empty first and last name raises an exception
        assertThrows(IllegalArgumentException.class, () -> contact.setFullName("", ""));
    }

    @Test
    void testAddValidPhoneNumber() {
        // Verifies that a valid phone number can be added successfully
        contact.addPhoneNumber("+39081222222");
        assertTrue(contact.getPhoneNumbers().contains("+39081222222"));
    }

    @Test
    void testAddInvalidPhoneNumber() {
        // Ensures that invalid phone numbers trigger an exception
        assertThrows(IllegalArgumentException.class, () -> contact.addPhoneNumber("abc"));
    }

    @Test
    void testAddPhoneNumberBeyondLimit() {
        // Ensures that adding more than the allowed number of phone numbers raises an error
        contact.setPhoneNumbers(Arrays.asList("+12345", "+23456", "+34567"));
        assertThrows(IllegalStateException.class, () -> contact.addPhoneNumber("+45678"));
    }

    @Test
    void testAddValidEmail() {
        // Verifies that a valid email can be added successfully
        contact.addEmail("newmail@example.com");
        assertTrue(contact.getEmails().contains("newmail@example.com"));
    }

    @Test
    void testAddInvalidEmail() {
        // Ensures that an invalid email format triggers an exception
        assertThrows(IllegalArgumentException.class, () -> contact.addEmail("wrong.mail"));
    }

    @Test
    void testAddEmailBeyondLimit() {
        // Checks that adding more than three email addresses is not allowed
        contact.setEmails(Arrays.asList("a@a.it", "b@b.it", "c@c.it"));
        assertThrows(IllegalStateException.class, () -> contact.addEmail("d@d.it"));
    }

    @Test
    void testRemovePhoneNumber() {
        // Verifies that removing a previously added phone number works correctly
        contact.addPhoneNumber("+39333111222");
        contact.removePhoneNumber("+39333111222");
        assertFalse(contact.getPhoneNumbers().contains("+39333111222"));
    }

    @Test
    void testRemoveEmail() {
        // Verifies that removing a previously added email works correctly
        contact.addEmail("temp@example.com");
        contact.removeEmail("temp@example.com");
        assertFalse(contact.getEmails().contains("temp@example.com"));
    }

    @Test
    void testIsValidPhone() {
        // Tests the static phone validation utility method with valid and invalid inputs
        assertTrue(Contact.isValidPhone("+39333111222"));
        assertFalse(Contact.isValidPhone("abc"));
    }

    @Test
    void testIsValidEmail() {
        // Tests the static email validation utility method with valid and invalid inputs
        assertTrue(Contact.isValidEmail("user@domain.com"));
        assertFalse(Contact.isValidEmail("user@domain"));
    }

    @Test
    void testEqualsAndHashCode() {
        // Verifies that two contacts with the same UUID are considered equal
        UUID id = UUID.randomUUID();
        Contact c1 = new Contact(id, "A", "B", null, null, "", "", false);
        Contact c2 = new Contact(id, "X", "Y", null, null, "", "", false);
        assertEquals(c1, c2);
        assertEquals(c1.hashCode(), c2.hashCode());
    }

    @Test
    void testToStringIncludesFullName() {
        // Ensures that the string representation of the contact includes the full name
        assertTrue(contact.toString().contains(contact.getFullName()));
    }

    @Test
    void testUuid() {
        // Verifies that the UUID assigned to a contact cannot be altered after creation
        UUID id = UUID.randomUUID();
        Contact c = new Contact(id, "Mario", "Rossi",
                Collections.emptyList(), Collections.emptyList(),
                "", "", false);

        UUID originalId = c.getId();
        UUID newId = UUID.randomUUID();

        assertEquals(originalId, c.getId()); // ID remains unchanged
        assertNotEquals(newId, c.getId());   // Comparison ensures immutability
    }
}