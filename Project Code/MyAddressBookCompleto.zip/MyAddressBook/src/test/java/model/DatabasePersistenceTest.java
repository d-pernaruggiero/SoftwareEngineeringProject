/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import org.junit.jupiter.api.Test;
import java.util.*;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

/**
 * Unit tests for the DatabasePersistence class.
 * @author davidepernaruggiero
 */
class DatabasePersistenceTest {

    private final DatabasePersistence persistence = new DatabasePersistence();
    
    @BeforeEach
    void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }
    
    @Test
    void testParseListCorrectly() {
        // Verifies that a semicolon-separated string is correctly split into a list
        List<String> list = persistence.parseList("a;b;c");
        assertEquals(3, list.size());
        assertEquals("b", list.get(1));
    }

    @Test
    void testParseListEmptyAndNull() {
        // Ensures that null or empty strings return an empty list instead of throwing an exception
        assertTrue(persistence.parseList("").isEmpty());
        assertTrue(persistence.parseList(null).isEmpty());
    }

    @Test
    void testAppendContactNull() {
        // Verifies that appending a null contact is safely rejected
        assertFalse(persistence.appendContact(null));
    }

    @Test
    void testUpdateContactNull() {
        // Ensures that updating a null contact returns false instead of causing a crash
        assertFalse(persistence.updateContact(null));
    }

    @Test
    void testDeleteContactNull() {
        // Checks that deleting a null reference is handled gracefully
        assertFalse(persistence.deleteContact(null));
    }

    @Test
    void testFileExists() {
        // Ensures the file existence check does not throw exceptions,
        // regardless of whether the underlying file actually exists
        assertDoesNotThrow(() -> persistence.fileExists());
    }

    @Test
    void testLoadContacts() {
        // Ensures that the loading process executes safely without exceptions
        assertDoesNotThrow(() -> persistence.loadContacts());
    }

    @Test
    void testSaveAndLoad() {
        // Verifies a full save–load cycle: a contact is persisted and correctly reloaded
        DatabasePersistence persistence = new DatabasePersistence();

        Contact contact = new Contact(UUID.randomUUID(), "Mario", "Rossi",
                Arrays.asList("+39081234567"), Arrays.asList("mario@acme.it"),
                "ACME", "note test", false);

        // Save the contact
        assertTrue(persistence.appendContact(contact));

        // Load all contacts and ensure the saved one is found
        List<Contact> loaded = persistence.loadContacts();
        boolean found = loaded.stream()
                .anyMatch(x -> x.getId().equals(contact.getId()));
        assertTrue(found);
        persistence.deleteContact(contact.getId());
    }
}