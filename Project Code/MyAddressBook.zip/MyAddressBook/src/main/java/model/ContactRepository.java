/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package model;

import java.util.List;
import java.util.UUID;
import javafx.collections.ObservableList;

/**
 *
 * @author davidepernaruggiero
 * 
 * @file ContactRepository.java
 * @brief Defines the core operations for managing contacts
 * 
 */

public interface ContactRepository {
    boolean addContact(Contact contact);
    boolean saveContact(Contact contact);
    boolean removeContact(Contact contact);
    Contact getContact(UUID id);
    ObservableList<Contact> search(String substring);
    List<Contact> filterFavorites();
    void sortByFirstNameAscending();
    void sortByFirstNameDescending();
    void sortByLastNameAscending();
    void sortByLastNameDescending();
    int indexOf(UUID id);
    ObservableList<Contact> getObservableContacts();
    boolean contains(Contact contact);
}
