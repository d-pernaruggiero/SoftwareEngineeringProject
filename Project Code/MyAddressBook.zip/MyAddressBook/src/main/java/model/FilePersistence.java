/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 *
 * @author davidepernaruggiero
 * @file FilePersistence.java
 * @brief Handles persistence of contacts to and from a CSV file.
 * 
 */

public class FilePersistence implements Persistence {
    public static final String DEFAULT_PATH = "contacts.csv";
    private final Path filePath;

    public FilePersistence() {
        this(DEFAULT_PATH);
    }

    public FilePersistence(String path) {
        this.filePath = Paths.get(path);
        initializeFile();
    }
    
    /** Creates the CSV file with header if it does not already exist. */
    private void initializeFile() {
        if (Files.exists(filePath)){
        } else {
            try (BufferedWriter writer = Files.newBufferedWriter(filePath)) {
                writer.write("UUID,FirstName,LastName,Phones,Emails,Company,Notes,Favorite");
                writer.newLine();
                System.out.println("CSV file created at first startup: " + filePath);
            } catch (IOException e) {
                System.out.println("Error creating CSV file: " + e.getMessage());
            }
        }
    }

    /** *  Adds a new contact to the CSV file.Creates the file if missing.
     * @param contact
     * @return
     */
    @Override
    public boolean appendContact(Contact contact) {
        if (contact == null) return false;

        String pathToFile = filePath.toString();
        boolean fileExists = Files.exists(filePath);

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(pathToFile, true))) {
            if (!fileExists) {
                bw.write("UUID,FirstName,LastName,Phones,Emails,Company,Notes,Favorite");
                bw.newLine();
            }

            String phones = String.join(";", contact.getPhoneNumbers());
            String emails = String.join(";", contact.getEmails());

            String[] values = {
                contact.getId().toString(),
                contact.getFirstName(),
                contact.getLastName(),
                phones,
                emails,
                contact.getCompany(),
                contact.getNotes(),
                String.valueOf(contact.isFavorite())
            };

            bw.write(String.join(",", values));
            bw.newLine();

            System.out.println("Contact successfully saved to CSV.");
            return true;

        } catch (IOException e) {
            System.out.println("Error writing CSV file: " + e.getMessage());
            return false;
        }
    }

    /** 
     * Updates an existing contact (matches by UUID).
     * @param contact
     * @return 
     */
    @Override
    public boolean updateContact(Contact contact) {
        if (contact == null) return false;
        List<Contact> all = loadContacts();
        boolean updated = false;

        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).getId().equals(contact.getId())) {
                all.set(i, contact);
                updated = true;
                break;
            }
        }

        return updated && saveAll(all);
    }

    /** 
     * Deletes a contact from the CSV (matches by UUID).
     * @param contactId
     * @return 
     */
    @Override
    public boolean deleteContact(UUID contactId) {
        if (contactId == null) return false;
        List<Contact> all = loadContacts();
        boolean removed = all.removeIf(c -> c.getId().equals(contactId));
        return removed && saveAll(all);
    }

    /** 
     * Loads all contacts from the CSV file into memory.
     * @return  
     */
    @Override
    public List<Contact> loadContacts() {
        List<Contact> contacts = new ArrayList<>();
        String pathToFile = filePath.toString();

        if (!Files.exists(filePath)) {
            System.out.println("CSV file not found. No contacts loaded.");
            return contacts;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(pathToFile))) {
            String line;
            boolean headerSkipped = false;

            while ((line = br.readLine()) != null) {
                if (!headerSkipped) {
                    headerSkipped = true; 
                    continue;
                }

                String[] values = line.split(",", -1); 
                if (values.length < 8) continue; 

                UUID id = UUID.fromString(values[0]);
                String firstName = values[1];
                String lastName = values[2];
                List<String> phones = parseList(values[3]);
                List<String> emails = parseList(values[4]);
                String company = values[5];
                String notes = values[6];
                boolean favorite = Boolean.parseBoolean(values[7]);

                Contact contact = new Contact(id, firstName, lastName, phones, emails, company, notes, favorite);
                contacts.add(contact);
            }

            System.out.println("Contacts successfully loaded from CSV.");

        } catch (IOException e) {
            System.out.println("Error reading CSV file: " + e.getMessage());
        }

        return contacts;
    }

    /** 
     * Checks if the CSV file exists.
     * @return 
     */
    @Override
    public boolean fileExists() {
        return Files.exists(filePath);
    }

    /** Helper method: rewrites the entire file with the provided list of contacts. */
    private boolean saveAll(List<Contact> contacts) {
        try (BufferedWriter writer = Files.newBufferedWriter(
                filePath,
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING)) {

            writer.write("UUID,FirstName,LastName,Phones,Emails,Company,Notes,Favorite");
            writer.newLine();
            for (Contact c : contacts) {
                writer.write(serializeContact(c));
                writer.newLine();
            }
            return true;
        } catch (IOException e) {
            System.out.println("Error saving contacts to CSV: " + e.getMessage());
            return false;
        }
    }

    /** Converts a Contact into a single CSV line. */
    private String serializeContact(Contact c) {
        String phones = String.join(";", c.getPhoneNumbers());
        String emails = String.join(";", c.getEmails());
        String[] values = {
            c.getId().toString(),
            c.getFirstName(),
            c.getLastName(),
            phones,
            emails,
            c.getCompany(),
            c.getNotes(),
            String.valueOf(c.isFavorite())
        };
        return String.join(",", values);
    }

    /** 
     * Converts a semicolon-separated string into a list of values.
     * @param field
     * @return  
     */
    @Override
    public List<String> parseList(String field) {
        if (field == null || field.isEmpty()) return new ArrayList<>();
        String[] parts = field.split(";");
        List<String> list = new ArrayList<>();
        for (String p : parts) {
            if (!p.trim().isEmpty()) list.add(p.trim());
        }
        return list;
    }
}
