/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.*;
import java.util.*;
import java.util.List;
import java.util.UUID;

/**
 * 
 * @author davidepernaruggiero
 * @file DatabasePersistence.java
 * @brief Handles data persistence
 */
public class DatabasePersistence implements Persistence {

    private static final String URL = "jdbc:postgresql://localhost:5432/AddressBook";
    private static final String USER = "postgres";        // user pgAdmin
    private static final String PASSWORD = "Basididati"; //password pgAdmin

    public DatabasePersistence() {
        initializeDatabase();
    }

    /**
     * 
     * Ensures that the "contacts" table exists in the database.
     * If it doesn’t, it is automatically created during initialization.
     */
    private void initializeDatabase() {
        String sql =
            "CREATE TABLE IF NOT EXISTS contacts (" +
            "id UUID PRIMARY KEY," +
            "first_name VARCHAR(50)," +
            "last_name VARCHAR(50)," +
            "phones TEXT," +
            "emails TEXT," +
            "company VARCHAR(100)," +
            "notes TEXT," +
            "favorite BOOLEAN" +
            ")";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Database initialized and contacts table ready.");
        } catch (SQLException e) {
            System.out.println("Error initializing database: " + e.getMessage());
        }
    }

    
    /** 
     * 
     * Inserts a new contact into the database
     * @param contact
     * @return true if the insertion was successful, false otherwise.
     */
    @Override
    public boolean appendContact(Contact contact) {
        if (contact == null) return false;
        String sql = "INSERT INTO contacts (id, first_name, last_name, phones, emails, company, notes, favorite) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setObject(1, contact.getId());
            ps.setString(2, contact.getFirstName());
            ps.setString(3, contact.getLastName());
            ps.setString(4, String.join(";", contact.getPhoneNumbers()));
            ps.setString(5, String.join(";", contact.getEmails()));
            ps.setString(6, contact.getCompany());
            ps.setString(7, contact.getNotes());
            ps.setBoolean(8, contact.isFavorite());
            ps.executeUpdate();

            System.out.println("Contact successfully saved to database.");
            return true;
        } catch (SQLException e) {
            System.out.println("Error inserting contact: " + e.getMessage());
            return false;
        }
    }

    /** 
     * 
     * Updates an existing contact in the database.
     * The record is matched by its UUID.
     * @param contact The contact containing the updated information.
     * @return true if the contact was updated, false otherwise.
     */
    @Override
    public boolean updateContact(Contact contact) {
        if (contact == null) return false;
        String sql =
            "UPDATE contacts SET " +
            "first_name = ?, last_name = ?, phones = ?, emails = ?, company = ?, notes = ?, favorite = ? " +
            "WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, contact.getFirstName());
            ps.setString(2, contact.getLastName());
            ps.setString(3, String.join(";", contact.getPhoneNumbers()));
            ps.setString(4, String.join(";", contact.getEmails()));
            ps.setString(5, contact.getCompany());
            ps.setString(6, contact.getNotes());
            ps.setBoolean(7, contact.isFavorite());
            ps.setObject(8, contact.getId());
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.out.println("Error updating contact: " + e.getMessage());
            return false;
        }
    }

    /** 
     *
     * Deletes a contact from the database using its UUID as identifier.
     * 
     * @param contactId The UUID of the contact to delete.
     * @return true if the deletion succeeded, false otherwise.
     */
    @Override
    public boolean deleteContact(UUID contactId) {
        if (contactId == null) return false;
        String sql = "DELETE FROM contacts WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setObject(1, contactId);
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.out.println("Error deleting contact: " + e.getMessage());
            return false;
        }
    }

    /** 
     * 
     * Loads all stored contacts from the database into memory.
     * 
     * @return A list of all contacts currently saved in the database.
     */
    @Override
    public List<Contact> loadContacts() {
        List<Contact> contacts = new ArrayList<>();
        String sql = "SELECT * FROM contacts";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                UUID id = (UUID) rs.getObject("id");
                String firstName = rs.getString("first_name");
                String lastName = rs.getString("last_name");
                List<String> phones = parseList(rs.getString("phones"));
                List<String> emails = parseList(rs.getString("emails"));
                String company = rs.getString("company");
                String notes = rs.getString("notes");
                boolean favorite = rs.getBoolean("favorite");

                Contact contact = new Contact(id, firstName, lastName, phones, emails, company, notes, favorite);
                contacts.add(contact);
            }
            System.out.println("Contacts successfully loaded from database.");
        } catch (SQLException e) {
            System.out.println("Error loading contacts: " + e.getMessage());
        }
        return contacts;
    }

    /** 
     * 
     * Checks if the database connection is valid.
     * This helps verify that the PostgreSQL server is reachable and configured correctly.
     * @return true if the connection is valid, false otherwise.
     */
    @Override
    public boolean fileExists() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            return conn.isValid(2);
        } catch (SQLException e) {
            return false;
        }
    }
    /** 
     * 
     * Utility method that converts a semicolon-separated string
     * into a list of trimmed values.
     * @param field The string field to parse.
     * @return A list of string values extracted from the field.
     */
    @Override
    public List<String> parseList(String field) {
        if (field == null || field.isEmpty()) return new ArrayList<>();
        String[] parts = field.split(";");
        List<String> list = new ArrayList<>();
        for (String p : parts) {
            if (!p.trim().isEmpty()) list.add(p.trim());
        }
        return list;
    }
}