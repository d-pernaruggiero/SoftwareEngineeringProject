/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.Comparator;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * @author davidepernaruggiero
 * @file AddressBook.java
 * @brief Implements the ContactRepository interface, managing contacts in memory and providing operations such as search, sorting, filtering, and CRUD manipulation
 */

public class AddressBook implements ContactRepository {
    
    /** The observable list of contacts that backs the UI table */
    private final ObservableList<Contact> contacts;

    
    /** Creates an empty address book */
    public AddressBook() {
        this.contacts = FXCollections.observableArrayList();
    }
    
    /**
     * Returns the index of a contact by UUID
     * @param id the unique contact identifier
     * @return the index if found, otherwise -1
     */
    @Override
    public int indexOf(UUID id) {
        for (int i = 0; i < contacts.size(); i++)
            if (contacts.get(i).getId().equals(id)) return i;
        return -1;
    }
   
    
    /**
     * Returns the observable list of contacts used by JavaFX
     * This list is bound to the UI and updates automatically when changed
     * It should not be used for persistence or bulk operations
     * @return an observable list of contacts
     */
    @Override
    public ObservableList<Contact> getObservableContacts() {
        return contacts;
    }

    /**
     * Adds a new contact to the address book if it doesn’t already exist
     * @param contact the contact to add
     * @return true if successfully added, false otherwise
     */
    @Override
    public boolean addContact(Contact contact) {
        if (contact == null || contains(contact)) return false;
        return contacts.add(contact);
    }

    /**
     * Updates an existing contact with new information
     * @param contact the contact containing updated data
     * @return true if the contact was found and updated, false otherwise
     */
    @Override
    public boolean saveContact(Contact contact) {
        if (contact == null) return false;
        int idx = indexOf(contact.getId());
        if (idx < 0) return false;
        contacts.set(idx, contact);
        return true;
    }

        /**
     * Removes a contact from the address book
     * @param contact the contact to remove
     * @return true if the contact was removed, false otherwise
     */
    @Override
    public boolean removeContact(Contact contact) {
        if (contact == null) return false;
        return contacts.removeIf(x -> x.getId().equals(contact.getId()));
    }

    /**
     * Retrieves a contact by its UUID
     * @param id the contact ID
     * @return the matching contact, or null if not found
     */
    @Override
    public Contact getContact(UUID id) {
        for (Contact contact : contacts) if (contact.getId().equals(id)) return contact;
        return null;
    }

    /**
     * Searches contacts whose first or last name contains a given substring (case-insensitive)
     * @param substring the search keyword
     * @return an observable list of matching contacts
     */
    @Override    
    public ObservableList<Contact> search(String substring) {
        if (substring == null || substring.isEmpty()) {
          return FXCollections.observableArrayList(contacts);
        }
        String lowSub = substring.toLowerCase();

        ObservableList<Contact> wanted = FXCollections.observableArrayList(
          contacts
            .stream()
            .filter(contact ->
              contact.getFirstName().toLowerCase().contains(lowSub) ||
              contact.getLastName().toLowerCase().contains(lowSub)
            )
            .collect(Collectors.toList())
        );
        return wanted;
      }

    /**
     * Returns only contacts marked as favorites
     * @return an observable list of favorite contacts
     */
    @Override
    public ObservableList<Contact> filterFavorites() {
        return FXCollections.observableArrayList(
            contacts.stream()
                    .filter(Contact::isFavorite)
                    .collect(Collectors.toList())
        );
    }

    /**
     * Sorts contacts alphabetically by first name (ascending)
     */
    @Override
    public void sortByFirstNameAscending() {
        FXCollections.sort(contacts, Comparator
                .comparing(Contact::getFirstName, String.CASE_INSENSITIVE_ORDER)
                .thenComparing(Contact::getLastName, String.CASE_INSENSITIVE_ORDER));
    }

    /**
     * Sorts contacts alphabetically by last name (ascending)
     */
    @Override
    public void sortByLastNameAscending() {
        FXCollections.sort(contacts, Comparator
                .comparing(Contact::getLastName, String.CASE_INSENSITIVE_ORDER)
                .thenComparing(Contact::getFirstName, String.CASE_INSENSITIVE_ORDER));
    }
    
    /**
     * Sorts contacts alphabetically by first name (descending)
     */
    @Override
    public void sortByFirstNameDescending() {
        FXCollections.sort(contacts, Comparator
            .comparing(Contact::getFirstName, String.CASE_INSENSITIVE_ORDER.reversed())
            .thenComparing(Contact::getLastName, String.CASE_INSENSITIVE_ORDER.reversed()));
    }

    /**
     * Sorts contacts alphabetically by last name (descending)
     */
    @Override
    public void sortByLastNameDescending() {
        FXCollections.sort(contacts, Comparator
            .comparing(Contact::getLastName, String.CASE_INSENSITIVE_ORDER.reversed())
            .thenComparing(Contact::getFirstName, String.CASE_INSENSITIVE_ORDER.reversed()));
    }
    
    /**
     * Checks if a given contact already exists in the address book
     * @param contact the contact to check
     * @return true if the contact exists, false otherwise
     */
    @Override
    public boolean contains(Contact contact) {
        return contact != null && indexOf(contact.getId()) >= 0;
    }
}