/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 *
 * @author davidepernaruggiero
 * @file Contact.java
 * @brief Represents a single contact entity in the Address Book, including personal data, 
 *        phone numbers, emails, and metadata such as company, notes, and favorite status.
 */

public final class Contact {
    
    /*-Constants-*/
    public static final int MAX_PHONE_COUNT = 3;
    public static final int MAX_EMAIL_COUNT = 3;
    public static final int NAME_MAX_LEN = 50;
    
    /*-Fields-*/
    private UUID id;
    private String firstName;
    private String lastName;
    private List<String> phoneNumbers;
    private List<String> emails;
    private String company;
    private String notes;
    private boolean favorite;
    
    /*-Constructors-*/
    /** 
     * Default constructor — creates an empty contact with a new unique UUID.
     */
    public Contact() {
        this(UUID.randomUUID(), "", "", new ArrayList<>(), new ArrayList<>(), "", "", false);
    }
    
    /**
     * Full constructor — used when creating or loading a contact.
     *
     * @param id           unique identifier of the contact (if null, a new UUID is generated)
     * @param firstName    contact’s first name
     * @param lastName     contact’s last name
     * @param phoneNumbers list of phone numbers (max 3)
     * @param emails       list of email addresses (max 3)
     * @param company      company name
     * @param notes        optional notes
     * @param favorite     whether the contact is marked as favorite
     */
    public Contact(
            UUID id,
            String firstName,
            String lastName,
            List<String> phoneNumbers,
            List<String> emails,
            String company,
            String notes,
            boolean favorite) {

        this.id = (id == null) ? UUID.randomUUID() : id;
        this.phoneNumbers = new ArrayList<>();
        this.emails = new ArrayList<>();
        this.company = (company == null) ? "" : company.trim();
        this.notes = (notes == null) ? "" : notes.trim();
        this.favorite = favorite;

        setFullName(firstName, lastName);
        setPhoneNumbers(phoneNumbers);
        setEmails(emails);
    }
    
    /*-Getters-*/
    
    public UUID getId() {
        return id;
    }

    public String getFirstName() { 
        return firstName; 
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public List<String> getPhoneNumbers() { 
        return Collections.unmodifiableList(phoneNumbers);
    }

    public List<String> getEmails() {
        return Collections.unmodifiableList(emails);
    }
    
    public String getCompany() { 
        return company;
    }

    public String getNotes() { 
        return notes; 
    }

    public boolean isFavorite() { 
        return favorite; 
    }
    
    /** 
     * Returns the full name as a single string, trimmed of extra spaces.
     * @return String
     */
    public String getFullName() {
        String fullName = (firstName + " " + lastName).trim();
        return fullName;
    }

    /*-Setters-*/
    /**
     * Sets both first and last names, ensuring that at least one is provided.
     * @param firstName
     * @param lastName
     */
    public void setFullName(String firstName, String lastName) {
        String fN = (firstName == null) ? "" : firstName.trim();
        String lN = (lastName == null) ? "" : lastName.trim();

        if (fN.isEmpty() && lN.isEmpty()) {
            throw new IllegalArgumentException("At least a first or last name must be specified.");
        }
        this.firstName = fN;
        this.lastName = lN;
    }
    
    /**
     * Replaces all phone numbers with a validated list. 
     * Accepts up to MAX_PHONE_COUNT (3) valid phone numbers.
     * @param phones
     */
    public void setPhoneNumbers(List<String> phones) {
        if (this.phoneNumbers == null) {
            this.phoneNumbers = new ArrayList<>();
        } else {
            this.phoneNumbers.clear();
        }
        if (phones == null) return;

        for (String p : phones) {
            if (p == null || p.trim().isEmpty()) continue;
            if (!isValidPhone(p))
                throw new IllegalArgumentException("Invalid phone number: " + p);
            if (phoneNumbers.size() >= MAX_PHONE_COUNT)
                throw new IllegalStateException("Maximum number of phone numbers reached.");
            phoneNumbers.add(p.trim());
        }
    }
    
    /**
     * Replaces all email addresses with a validated list. 
     * Accepts up to MAX_EMAIL_COUNT (3) valid email addresses.
     * @param emails
     */
    public void setEmails(List<String> emails) {
        if (this.emails == null) {
            this.emails = new ArrayList<>();
        } else {
            this.emails.clear();
        }
        if (emails == null) return;

        for (String e : emails) {
            if (e == null || e.trim().isEmpty()) continue;
            if (!isValidEmail(e))
                throw new IllegalArgumentException("Invalid email format: " + e);
            if (this.emails.size() >= MAX_EMAIL_COUNT)
                throw new IllegalStateException("Maximum number of emails reached.");
            this.emails.add(e.trim());
        }
    }

    public void setCompany(String company) {
        this.company = (company == null) ? "" : company.trim();
    }
    
    public void setNotes(String notes) {
        this.notes = (notes == null) ? "" : notes.trim();
    }
    
    public void setFavorite(boolean favorite) { 
        this.favorite = favorite; 
    }
    
    /*-Methods-*/
    
    /** 
     * Adds a new phone number if valid and below the limit.
     * @param number 
     */
    public void addPhoneNumber(String number) {
        if (this.phoneNumbers == null) {
            this.phoneNumbers = new ArrayList<>();
        }
        if (number == null || number.trim().isEmpty()){
            return;
        } else if (!isValidPhone(number)){
            throw new IllegalArgumentException("Invalid phone number format.");
        } else if(phoneNumbers.size() >= MAX_PHONE_COUNT){
            throw new IllegalStateException("Maximum number of phone numbers reached.");
        }
        phoneNumbers.add(number.trim());
    }
    
    /** 
     * Removes a specific phone number from the list.
     * @param number
     */
    public void removePhoneNumber(String number) {
        if (this.phoneNumbers != null) {
            phoneNumbers.remove(number);
        }
    }  
    
    /** 
     * Adds a new email address if valid and below the limit.
     * @param email
     */
    public void addEmail(String email) {
        if (this.emails == null) {
            this.emails = new ArrayList<>();
        }
        if (email == null || email.trim().isEmpty()){
            return;
        } else if (!isValidEmail(email)) {
            throw new IllegalArgumentException("Invalid email format.");
        } else if (emails.size() >= MAX_EMAIL_COUNT){
            throw new IllegalStateException("Maximum number of emails reached.");
        } else emails.add(email.trim());
    }
    
    /** 
     * Removes a specific email address from the list.
     * @param email
     */
    public void removeEmail(String email) {
        if (this.emails != null) {
            emails.remove(email);
        }
    }
    
    /**
     * Validates phone numbers. Accepts digits, spaces, and dashes, with an optional '+' prefix.
     * @param number
     * @return boolean
     */
    public static boolean isValidPhone(String number) {
        if (number == null || number.trim().isEmpty()){
            return false;
        } else { 
            return number.matches("^\\+?[0-9\\s-]{5,20}$");
        } 
    }
    
    /**
     * Validates email addresses. Ensures proper format with characters before and after '@'.
     * @param email
     * @return boolean
     */
    public static boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) return false;
        return email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }
    
    /**-Overrides-*/
    
    @Override public String toString() {
        return "Contact{" + getFullName() + "}";
    }

    @Override public boolean equals(Object obj) {
        return obj instanceof Contact && id != null && id.equals(((Contact) obj).id);
    }

    @Override public int hashCode() {
        return id == null ? 0 : id.hashCode();
    }
}