/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package model;

import model.Contact;
import java.util.List;
import java.util.UUID;

/**
 *
 * @author davidepernaruggiero
 * Defines the persistence layer for saving and retrieving contacts
 * from a permanent storage
 * 
 */

public interface Persistence {
    boolean appendContact(Contact contact);
    boolean updateContact(Contact contact);
    boolean deleteContact(UUID contactId);
    List<Contact> loadContacts();
    boolean fileExists();
    List<String> parseList(String field);
}
