/*
* Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
* Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
*/
package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import model.Contact;
import model.ContactRepository;
import model.Persistence;
import view.App;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 *
 * @author davidepernaruggiero
 * @file ContactEditController
 * @brief Controller for the contact edit view
 * this class handles both the creation of new contacts and the editing of existing ones
 * 
 * It maps user inputs from the form to a {@link Contact} object, validates the data, and 
 * triggers persistence operations (database or file) through the {@link Persistence} interface
 */
public class ContactEditController {

    /*-Data Models-*/
    private ContactRepository repository;
    private Persistence persistence;
    private Contact editing; // The contact currently being edited (null if new)
    /*-UI Components-*/
    @FXML private TextField firstNameField;
    @FXML private TextField lastNameField;
    @FXML private TextField companyField;
    @FXML private TextArea notesArea;
    @FXML private CheckBox favoriteCheck;
    @FXML private TextField phone1, phone2, phone3;
    @FXML private TextField email1, email2, email3;
    @FXML private Button saveBtn, backBtn;

    /**
     * Initializes the controller with the given repository and persistence handler
     * If an existing contact is passed, its data is automatically loaded into the form
     * @param repository  the contact data source (in-memory list)
     * @param persistence the persistence manager (database or file)
     * @param contact     the contact to edit, or null if creating a new one
     */
    public void init(ContactRepository repository, Persistence persistence, Contact contact) {
        
        this.repository = repository;
        this.persistence = persistence;
        this.editing = contact; 

        if (contact != null) populateForm(contact);
    }

    /**
     * Fills the form fields with an existing contact’s information
     * This method is used when editing a saved contact
     * @param contact the contact to load into the form
     */
    private void populateForm(Contact contact) {
        firstNameField.setText(contact.getFirstName());
        lastNameField.setText(contact.getLastName());
        companyField.setText(contact.getCompany());
        notesArea.setText(contact.getNotes());
        favoriteCheck.setSelected(contact.isFavorite());

        List<String> phones = contact.getPhoneNumbers();
        phone1.setText(phones.size() > 0 ? phones.get(0) : "");
        phone2.setText(phones.size() > 1 ? phones.get(1) : "");
        phone3.setText(phones.size() > 2 ? phones.get(2) : "");

        List<String> emails = contact.getEmails();
        email1.setText(emails.size() > 0 ? emails.get(0) : "");
        email2.setText(emails.size() > 1 ? emails.get(1) : "");
        email3.setText(emails.size() > 2 ? emails.get(2) : "");
    }

    /**
     * Builds a new {@link Contact} object from the current form input
     * Performs light validation (non-empty fields) before creation
     * @return a fully constructed {@link Contact} instance
     */
    private Contact buildContactFromInput() {
        List<String> phones = new ArrayList<>();
        if (notBlank(phone1)) phones.add(phone1.getText().trim());
        if (notBlank(phone2)) phones.add(phone2.getText().trim());
        if (notBlank(phone3)) phones.add(phone3.getText().trim());

        List<String> emails = new ArrayList<>();
        if (notBlank(email1)) emails.add(email1.getText().trim());
        if (notBlank(email2)) emails.add(email2.getText().trim());
        if (notBlank(email3)) emails.add(email3.getText().trim());

        UUID id = (editing == null) ? null : editing.getId();

        return new Contact(
                id,
                firstNameField.getText(),
                lastNameField.getText(),
                phones,
                emails,
                companyField.getText(),
                notesArea.getText(),
                favoriteCheck.isSelected()
        );
    }

    /**
     * Utility method to check whether a text field contains non-empty content.
     * @param field the {@link TextField} to validate
     * @return true if non-empty, false otherwise
     */
    private boolean notBlank(TextField field) {
        return field != null && field.getText() != null && !field.getText().trim().isEmpty();
    }

    /**
     * Handles the “Save” button action
     * Validates and saves the contact—either creating a new entry or updating an existing one
     * After saving, the main view is reloaded
     */
    @FXML
    public void handleSaveContact() {
        try {
            Contact contact = buildContactFromInput();

            if (editing == null) {
                // New contact
                if (repository.addContact(contact)) {
                    persistence.appendContact(contact);
                }
            } else {
                // Edit existing contact
                if (repository.saveContact(contact)) {
                    persistence.updateContact(contact);
                }
            }

            showMainView();

        } catch (Exception e) {
            showError("Error while saving contact: " + e.getMessage());
        }
    }

    /**
     * Handles the “Cancel” button action
     * Returns the user to the main contact list without saving
     */
    @FXML
    public void handleBack() {
        showMainView();
    }

    /**
     * Switches the view back to the main Address Book screen (fixed size)
     */
    private void showMainView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MainView.fxml"));
            Parent root = loader.load();

            MainViewController mainController = loader.getController();
            mainController.init(repository, persistence);

            Stage stage = App.getPrimaryStage();
            stage.setScene(new Scene(root, 1000, 700));
            stage.setResizable(false);
            stage.setTitle("My Address Book");
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Displays an error alert with a user-friendly message
     * @param message the text to show in the alert dialog
     */
    private void showError(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Validation Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}