/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;


import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import model.Contact;
import model.ContactRepository;
import model.Persistence;
import view.App;
import java.io.IOException;
import java.util.List;

/**
 * @author davidepernaruggiero
 * @file ContactDetailController.java
 * @brief Controller for the Contact Detail view
 * This controller manages the detailed view of a single contact
 * It displays all saved information (names, company, phones, emails, etc.)
 * and provides user actions for editing, deleting, or returning to the main view
 */
public class ContactDetailController {

    /*-Data Models-*/
    private ContactRepository repository;
    private Persistence persistence;
    private Contact contact;
    
    /*-UI Components-*/
    @FXML private Label firstNameField;
    @FXML private Label lastNameField;
    @FXML private Label companyLabel;
    @FXML private Label notesLabel;
    @FXML private Label favoriteLabel;
    @FXML private Label phone1, phone2, phone3;
    @FXML private Label email1, email2, email3;
    @FXML private Button editContactBtn;
    @FXML private Button deleteContactBtn;
    @FXML private Button backBtn;

    /**
     * Initializes the controller with repository, persistence handler, and the contact to display
     * Populates the labels with the contact’s information
     * @param repository the in-memory data manager (AddressBook)
     * @param persistence the persistence manager (Database or File)
     * @param contact the contact whose details are displayed
     */
    public void init(ContactRepository repository, Persistence persistence, Contact contact) {
        this.repository = repository;
        this.persistence = persistence;
        this.contact = contact;

        updateLabels();
    }

    /**
     * Opens the edit view for the current contact
     * The existing contact data is passed to the {@link ContactEditController}.
     */
    @FXML
    public void handleEditContact() {
        if (contact == null) return;

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ContactEditView.fxml"));
            Parent root = loader.load();

            ContactEditController editController = loader.getController();
            editController.init(repository, persistence, contact);

            Stage stage = App.getPrimaryStage();
            stage.setScene(new Scene(root, 1000, 700));
            stage.setResizable(false);
            stage.setTitle("My Address Book");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Handles contact deletion with a confirmation dialog
     * The contact is removed from both the repository and the persistence layer
     */
    @FXML
    public void handleDeleteContact() {
        if (contact == null) return;

        Alert confirm = new Alert(AlertType.CONFIRMATION);
        confirm.setTitle("Delete Contact");
        confirm.setHeaderText("Are you sure you want to delete this contact?");
        confirm.setContentText(contact.getFullName());

        confirm.showAndWait().ifPresent(response -> {
            if (response.getButtonData() == ButtonBar.ButtonData.OK_DONE) {
                repository.removeContact(contact);
                persistence.deleteContact(contact.getId());
                showMainView();
            }
        });
    }

    /**
     * Returns to the main contact list without making changes
     */
    @FXML
    public void handleBack() {
        showMainView();
    }

    /**
     * Loads and displays the main view (Address Book) with fixed dimensions
     * Used after editing, deleting, or navigating back
     */
    private void showMainView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MainView.fxml"));
            Parent root = loader.load();

            MainViewController mainController = loader.getController();
            mainController.init(repository, persistence);

            Stage stage = App.getPrimaryStage();
            stage.setScene(new Scene(root, 1000, 700));
            stage.setResizable(false);
            stage.setTitle("Address Book");
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Updates all the UI labels with the contact’s current data
     * Displays the contact’s name, phone numbers, emails, notes, and favorite status
     */
    private void updateLabels() {
        if (contact == null) return;

        firstNameField.setText(contact.getFirstName());
        lastNameField.setText(contact.getLastName());
        companyLabel.setText(contact.getCompany());
        notesLabel.setText(contact.getNotes());
        favoriteLabel.setText(contact.isFavorite() ? "★" : " ");

        List<String> phones = contact.getPhoneNumbers();
        phone1.setText(phones.size() > 0 ? phones.get(0) : "");
        phone2.setText(phones.size() > 1 ? phones.get(1) : "");
        phone3.setText(phones.size() > 2 ? phones.get(2) : "");

        List<String> emails = contact.getEmails();
        email1.setText(emails.size() > 0 ? emails.get(0) : "");
        email2.setText(emails.size() > 1 ? emails.get(1) : "");
        email3.setText(emails.size() > 2 ? emails.get(2) : "");
    }
}