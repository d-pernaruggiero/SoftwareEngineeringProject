/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.Contact;
import model.ContactRepository;
import model.Persistence;
import view.App;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * @author davidepernaruggiero
 * @file MainViewController.java
 * @brief Controls the main view of the Address Book application
 * This class acts as the central controller for the primary interface
 * It manages the visualization of contacts, user interactions such as searching, sorting, and filtering, and navigates between views
 */
public class MainViewController implements Initializable {
    
    /*UI Components*/
    @FXML private TableView<Contact> contacts;
    @FXML private TableColumn<Contact, String> contactFirstName;
    @FXML private TableColumn<Contact, String> contactLastName;
    @FXML private TextField search;
    @FXML private Button searchBtn;
    @FXML private Button addBtn;
    @FXML private Button sortByFirstNameBtn;
    @FXML private Button sortByLastNameBtn;
    @FXML private Button filterByFavouriteBtn;
    @FXML private Button clearBtn;

    /*-Model-*/
    private ContactRepository repository;
    
    private Persistence persistence;

    /* A FilteredList allows dynamic filtering of the observable contact list */
    private FilteredList<Contact> filteredContacts;
    
    /* UI state flags */
    private boolean showingFavorites = false;
    private boolean sortedByFirstName = false;
    private boolean sortedByLastName = false;

    /**
     * Called automatically by JavaFX after the FXML view is loaded
     * Sets up the table columns and layout behavior
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        contactFirstName.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        contactLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        contacts.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    /**
     * Initializes the controller after creation
     * 
     * @param repository the data source for contacts
     * @param persistence the persistence layer 
     */
    public void init(ContactRepository repository, Persistence persistence) {
        this.repository = repository;
        this.persistence = persistence;
        filteredContacts = new FilteredList<>(repository.getObservableContacts(), c -> true);
        contacts.setItems(filteredContacts);
    }
 
    /**
     * Opens the "Add Contact" view
     * Loads the FXML for contact creation and switches the scene
     */
    @FXML
    public void handleAddContact() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ContactEditView.fxml"));
            Parent root = loader.load();
            ContactEditController editController = loader.getController();
            editController.init(repository, persistence, null);
            Stage stage = App.getPrimaryStage();
            stage.setScene(new Scene(root, 1000, 700));
            stage.setTitle("My Address Book");
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Sorts contacts by first name, toggling between ascending and descending order
     */
    @FXML
    public void handleSortByFirstName() {
        if (sortedByFirstName) repository.sortByFirstNameDescending();
        else repository.sortByFirstNameAscending();
        sortedByFirstName = !sortedByFirstName;
        sortedByLastName = false;
        contacts.refresh();
    }

    /**
     * Sorts contacts by last name, toggling between ascending and descending order.
     */
    @FXML
    public void handleSortByLastName() {
        if (sortedByLastName) repository.sortByLastNameDescending();
        else repository.sortByLastNameAscending();
        sortedByLastName = !sortedByLastName;
        sortedByFirstName = false;
        contacts.refresh();
    }
    
    /**
     * Toggles between showing all contacts and only those marked as favorites.
     */
    @FXML
    public void handleFilterByFavorite() {
        if (showingFavorites) filteredContacts.setPredicate(c -> true);
        else filteredContacts.setPredicate(Contact::isFavorite);
        showingFavorites = !showingFavorites;
        contacts.refresh();
    }

    /**
     * Clears any active search or filter and resets the contact list view.
     */
    @FXML
    public void handleClearBtn() {
        if (search != null) search.clear();
        showingFavorites = false;
        filteredContacts.setPredicate(contact -> true);
        contacts.refresh();
    }

    /**
     * Filters the contact list in real-time based on user input in the search bar.
     */
    @FXML
    public void handleSearch() {
        String q = (search != null) ? search.getText().trim().toLowerCase() : "";
        filteredContacts.setPredicate(contact ->
                q.isEmpty() ||
                contact.getFirstName().toLowerCase().contains(q) ||
                contact.getLastName().toLowerCase().contains(q));
        contacts.refresh();
    }

    /**
     * Opens the detailed contact view when a user double-clicks a row in the table.
     * @param event the mouse click event
     */
    @FXML
    public void handleOpenContact(MouseEvent event) {
        if (event.getClickCount() == 2 && contacts.getSelectionModel().getSelectedItem() != null) {
            Contact selected = contacts.getSelectionModel().getSelectedItem();
            showDetailView(selected);
        }
    }

    /**
     * Loads and displays the detailed view for a selected contact.
     * @param contact the contact to display
     */
    private void showDetailView(Contact contact) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ContactDetailView.fxml"));
            Parent root = loader.load();
            ContactDetailController detailController = loader.getController();
            detailController.init(repository, persistence, contact);
            Stage stage = App.getPrimaryStage();
            stage.setScene(new Scene(root, 1000, 700));
            stage.setTitle("My Address Book");
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }
}