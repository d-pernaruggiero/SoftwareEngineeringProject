/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import controller.MainViewController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.AddressBook;
import model.ContactRepository;
import model.DatabasePersistence;
import model.Persistence;
/* 
 * To test the software using file-based persistence, just switch to CSV mode:
 * import model.FilePersistence;
 */


/**
 *
 * @author davidepernaruggiero
 * @file App.java
 * @brief Main entry point for the Address Book application
 */

public class App extends Application {

    private static Stage primaryStage;
    private static ContactRepository repository;
    private static Persistence persistence;

    @Override
    public void start(Stage stage) throws Exception {
        primaryStage = stage;

        repository = new AddressBook();
        // persistence = new FilePersistence();
        /*
         * Uncomment line 42 and comment line 46 to switch persistence
         * from PostgreSQL database to CSV file.
         */
        persistence = new DatabasePersistence();

        // Load contacts from either the database or the CSV file
        persistence.loadContacts().forEach(repository::addContact);

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MainView.fxml"));
        Parent root = loader.load();

        MainViewController controller = loader.getController();
        controller.init(repository, persistence);

        Scene scene = new Scene(root, 1000, 700);
        stage.setScene(scene);
        stage.setTitle("My Address Book");
        stage.setResizable(false);
        stage.show();
    }

    public static Stage getPrimaryStage() {
        return primaryStage;
    }
}